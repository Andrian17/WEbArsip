
<script src="../js/jquery.js"></script>
<script src="../js/jquery.ui.widget.js"></script>
<script src="../js/jquery.iframe-transport.js"></script>
<script src="../js/jquery.fileupload.js"></script>
<script src="../js/script.js"></script>
</body>
</html>