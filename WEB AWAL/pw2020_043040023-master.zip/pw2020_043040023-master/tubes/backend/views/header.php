<!doctype html>
<html>
<head>
	<title>Daftar Teman</title>
	<link rel="stylesheet" href="../css/font.css">
	<link rel="stylesheet" href="../css/gumby.css">
	<link rel="stylesheet" href="../css/jquery.fileupload.css">
	<link rel="stylesheet" href="../css/style.css">
</head>
<body>